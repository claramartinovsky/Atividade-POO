public class EquacaoSegundoGrau {
    private double a, b, c;

    public EquacaoSegundoGrau(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    private double calcularDelta() {
        return Math.pow(b, 2) - 4 * a * c;
    }

    public void calcularRaizes() {
        double delta = calcularDelta();

        if (delta > 0) {
            double x1 = (-b + Math.sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.sqrt(delta)) / (2 * a);
            System.out.println("Raízes reais distintas:");
            System.out.println("x1 = " + x1);
            System.out.println("x2 = " + x2);
        } else if (delta == 0) {
            double x = -b / (2 * a);
            System.out.println("Raízes reais iguais:");
            System.out.println("x = " + x);
        } else {
            System.out.println("Não existem raízes reais para essa equação.");
        }
    }
}
