public class DesvioPadrao {

    public static double calcularMedia(double[] valores) {
        double soma = 0.0;
        for (double valor : valores) {
            soma += valor;
        }
        return soma / valores.length;
    }

    public static double calcularDesvioPadrao(double[] valores) {
        double media = calcularMedia(valores);
        double soma = 0.0;
        for (double valor : valores) {
            soma += Math.pow(valor - media, 2);
        }
        return Math.sqrt(soma / valores.length);
    }
}

