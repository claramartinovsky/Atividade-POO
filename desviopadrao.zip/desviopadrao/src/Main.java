import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o número de elementos: ");
        int n = scanner.nextInt();

        double[] valores = new double[n];

        System.out.println("Digite os valores:");
        for (int i = 0; i < n; i++) {
            System.out.print("Valor " + (i + 1) + ": ");
            valores[i] = scanner.nextDouble();
        }

        double desvioPadrao = DesvioPadrao.calcularDesvioPadrao(valores);

        System.out.println("O desvio padrão é: " + desvioPadrao);

        scanner.close();
    }
}
