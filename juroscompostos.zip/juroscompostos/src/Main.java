import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o capital inicial: ");
        double capital = scanner.nextDouble();

        System.out.print("Digite a taxa de juros em %: ");
        double taxa = scanner.nextDouble();

        System.out.print("Digite o tempo em meses: ");
        int tempo = scanner.nextInt();

        double montante = JurosCompostos.calcularMontante(capital, taxa, tempo);
        double juros = JurosCompostos.calcularJuros(capital, montante);

        System.out.println("Montante final: " + montante);
        System.out.println("Juros obtidos: " + juros);

        scanner.close();
    }
}
