public class JurosCompostos {

    public static double calcularMontante(double capital, double taxa, int tempo) {
        return capital * Math.pow((1 + taxa / 100), tempo);
    }

    public static double calcularJuros(double capital, double montante) {
        return montante - capital;
    }
}
